----------------------------------------------
bay without template
----------------------------------------------
(res,rec) << my_api.create(:bay,
#:model, "7' Relay Rack",
:spec_id , "Alcatel ADM Rack", 
:lower_left,  pam.trail.coords[1],
:description, "my_api_bay",
:construction_status, "In Service",
:location, pam.trail.coords[1],
:owner, "mit_hub=6959827068163164721",
:number,"10")
$

----------------------------------------------
bay with_template, :bay: tmplate bay name & owner= "hub record"
------------------------------------------------
(res, rec) << my_api.create_from_template(
:bay, "my_api_bay1",
:lower_left,  pam.trail.coords[1],
:owner, template_hub,
:description, "PT2")
$
---------------------------------------------------
shelf with template
---------------------------------------------------

