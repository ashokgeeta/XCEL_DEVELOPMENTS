 my_api.create(:underground_route,#:id , 12345,
                         :name, "Api_UGR",
			 :underground_route_type, "Trench",
:width, 100,
:construction_status, "In Service",
:upper_material_depth, 100,
:core_material_depth,100,
:base_material_depth,100,
:route, (504442434.97302583278,206918833.4542899188-504827760.93978865006,206906535.8170528057) 
)
$

(my_res,my_api) << cyl_pni_nw_creator_base.new( :design_spec, "All Specs" ,
                           :mit_dataset_name , :gis,  
                           :mit_alternative , "|Engineering Design|PLAN_2592" ,
                           :mit_alternative_mode , :write )
$

---------------------------------------
building [my_api = instance of cyl_pni_nw_creator_base class
---------------------------------------
(res, rec) << my_api.create(:building,
	 :name, "BBC",
	 :type, "Commercial",
	 :location ,  pam.trail.coords
)
$
-------------------------------------------
MIt_building_struc
---------------------------------------
(res,rec) <<
my_api.create(:building_structure,
:building, my_build,
:number_of_floors, 2,
:underground_floors, 1,
:floor_length, 100,
:floor_width, 100
)

-------------------------------------------
Manhole
-------------------------------------------
(res, rec) << my_api.create(:uub,
	 :label, "MY_uub",
	 :type, "Manhole",
         :model,"standard",
	 :spec_id , "standard", 
         :construction_status,"In Service",
	 :location ,  pam.trail.coords
)
$

-------------------------------
UGR:sec=[sec << rope.new_with("504718030.000,206775540.000", "504772266.000,206775882.000")]
----------------------
(res,rec) << my_api.create(:underground_route,#:id , 12345,
                         :name, "Api_UGR",
			 :underground_route_type, "Trench",
:width, 100,
:construction_status, "In Service",
:upper_material_depth, 100,
:core_material_depth,100,
:base_material_depth,100,
:route, sec
)
$
---------------------------------------
cable: r1: r1 << property_list.new_with(:uub, "6959827068163164727")
----------------------------
(res,rec) << my_api.create(:sheath_with_loc,#:id , 12345,
                         :name, "Api_cable",
			 :spec_id, "AT&T LXE 12",
			 :construction_status, "In Service",
			 :struture, r1
)
$
---------------------------------------------
conduit_adapter[r1 is only single strucutre[property_list.new_with(:uub, "6959827068163164727")
--------------------------------------------
(res,rec) << my_api.create(:conduit_adapter,#:id , 12345,
                         :label, "Api_conduit_adapter",
			 :spec_id, "Reducer:200mm-100mm",
			 :construction_status, "In Service",
			 :struture, r1
)
$

-----------------------------------------------
mit_conduit: r1:[r1 << property_list.new_with(:mit_hub, "6959827068163164721", :mode, "straight_through",
	       			       :underground_route, "6959827068163164997", :mode, "straight_through", 
				       	:uub, "6959827068163164727", :mode, "straight_through" )
$
-----------------------------------------------


(res,rec) << my_api.create(:mit_conduit,#:id , 12345,
                         :name, "Api_conduit1",
			 :spec_id, "0.3m Standard",
			 :construction_status, "In Service",
			 :usage, "Any",
			 :struture, r1
)
$
--------------------------------------------
sheath_splice
---------------------------------------------
res,rec) << my_api.create(:sheath_splice,#:id , 12345,
                         :name, "Api_sheath_splice",
			 :spec_id, "Splice 2",
			 :construction_status, "In Service",
			 :splice_type, "breaking",
			 :splice_method, "Fusion",
			 :struture, r1
)
$
----------------------------------------------
BAY
----------------------------------------------
(res,rec) << my_api.create(:bay,
#:model, "7' Relay Rack",
:spec_id , "Nortel Bay - 25mm MS", 
:lower_left,  pam.trail.coords,
:description, "my_api_bay",
:construction_status, "In Service",
:owner, hub,
:number,"10")
$