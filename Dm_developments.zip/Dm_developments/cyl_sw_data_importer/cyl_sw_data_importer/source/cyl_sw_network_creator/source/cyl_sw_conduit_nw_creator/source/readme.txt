 my_api.create(:underground_route,#:id , 12345,
                         :name, "Api_UGR",
			 :underground_route_type, "Trench",
:width, 100,
:construction_status, "In Service",
:upper_material_depth, 100,
:core_material_depth,100,
:base_material_depth,100,
:route, (504442434.97302583278,206918833.4542899188-504827760.93978865006,206906535.8170528057) 
)
$

(my_res,my_api)<< mit_api.new( :design_spec          , "All Specs"        ,
                           :mit_dataset_name     , :gis               ,
                           :mit_alternative      , "|Engineering Design|PLAN_2592" ,
                           :mit_alternative_mode , :write             )
	 	    		   
$
sec.add_last(pam.trail.coords[2])
$
-------------------------------
UGR
----------------------
(res,rec) << my_api.create(:underground_route,#:id , 12345,
                         :name, "Api_UGR",
			 :underground_route_type, "Trench",
:width, 100,
:construction_status, "In Service",
:upper_material_depth, 100,
:core_material_depth,100,
:base_material_depth,100,
:route, sec
)
$
---------------------------------------
cable
----------------------------
(res,rec) << my_api.create(:sheath_with_loc,#:id , 12345,
                         :name, "Api_cable",
			 :spec_id, "AT&T LXE 12",
			 :construction_status, "In Service",
			 :struture, r1
)
$
---------------------------------------------
conduit_adapter[r1 is only single strucutre
--------------------------------------------
(res,rec) << my_api.create(:mit_conduit,#:id , 12345,
                         :label, "Api_conduit_adapter",
			 :spec_id, "Reducer:200mm-100mm",
			 :construction_status, "In Service",
			 :struture, r1
)
$
--------------------------------------------
sheath_splice
---------------------------------------------
res,rec) << my_api.create(:sheath_splice,#:id , 12345,
                         :name, "Api_sheath_splice",
			 :spec_id, "Splice 2",
			 :construction_status, "In Service",
			 :splice_type, "breaking",
			 :splice_method, "Fusion",
			 :struture, r1
)
$
----------------------------------------------
Sheath_with_loc_terminal
----------------------------------------------